from age.scripts.seed_catalog import seed

if __name__ == "__main__":
    seed()
