from age.training.train import main

if __name__ == "__main__":
    main()
