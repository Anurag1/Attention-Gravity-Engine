print("placeholder training entrypoint for ranker")
