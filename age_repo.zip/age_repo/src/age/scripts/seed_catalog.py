from sqlalchemy.orm import Session
from age.db.session import SessionLocal, engine, Base
from age.db.models import Item, UserState
from age.config.settings import get_settings
from age.core.embeddings import text_to_embedding

TOPICS = ["ai", "systems", "finance", "science", "design", "product", "history", "coding"]


def seed():
    Base.metadata.create_all(bind=engine)
    settings = get_settings()
    db: Session = SessionLocal()
    existing = db.query(Item).count()
    if existing > 0:
        print(f"catalog already seeded: {existing} items")
        db.close()
        return
    for i in range(settings.seed_items):
        topic = TOPICS[i % len(TOPICS)]
        title = f"{topic.title()} insight {i}"
        body = f"Synthetic content about {topic} and pattern {i}."
        item = Item(
            item_id=f"item_{i}",
            title=title,
            body=body,
            topic=topic,
            embedding=text_to_embedding(f"{title} {body} {topic}", dim=settings.embed_dim),
            freshness=1.0 - ((i % 20) / 25.0),
        )
        db.add(item)
    db.commit()
    print(f"seeded {settings.seed_items} items")
    db.close()


if __name__ == "__main__":
    seed()
