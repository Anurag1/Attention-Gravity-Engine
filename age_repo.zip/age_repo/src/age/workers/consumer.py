import json
import time
from redis import Redis
from sqlalchemy.orm import Session
from age.config.settings import get_settings
from age.db.session import SessionLocal, engine, Base
from age.core.schemas import EventIn
from age.ingestion.events import STREAM_NAME
from age.db.models import Item, Event
from age.core.state import get_user_state, save_user_state, update_state_from_reaction


def process_event(db: Session, payload: dict):
    event = EventIn(**payload)
    state = get_user_state(db, event.user_id)
    item = db.get(Item, event.item_id) if event.item_id else None
    if item is None:
        db.add(Event(user_id=event.user_id, item_id=event.item_id, event_type=event.event_type, value=event.value, context=event.context))
        db.commit()
        return
    new_state = update_state_from_reaction(state, item.embedding or [], event.event_type, event.value)
    save_user_state(db, new_state)


def main():
    settings = get_settings()
    Base.metadata.create_all(bind=engine)
    redis_client = Redis.from_url(settings.redis_url, decode_responses=True)
    group = "age-workers"
    consumer = f"c-{int(time.time())}"
    try:
        redis_client.xgroup_create(STREAM_NAME, group, id="0-0", mkstream=True)
    except Exception:
        pass
    while True:
        try:
            messages = redis_client.xreadgroup(group, consumer, {STREAM_NAME: ">"}, count=10, block=5000)
            if not messages:
                continue
            db: Session = SessionLocal()
            for _, entries in messages:
                for message_id, fields in entries:
                    payload = json.loads(fields["event"])
                    process_event(db, payload)
                    redis_client.xack(STREAM_NAME, group, message_id)
            db.close()
        except KeyboardInterrupt:
            break
        except Exception as exc:
            print(f"worker error: {exc}")
            time.sleep(1)


if __name__ == "__main__":
    main()
