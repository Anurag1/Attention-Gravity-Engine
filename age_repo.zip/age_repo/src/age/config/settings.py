from functools import lru_cache
from pydantic import BaseModel
import os
from dotenv import load_dotenv

load_dotenv()


class Settings(BaseModel):
    app_name: str = os.getenv("APP_NAME", "Attention Gravity Engine")
    env: str = os.getenv("ENV", "dev")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./age.db")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    embed_dim: int = int(os.getenv("EMBED_DIM", "64"))
    seed_items: int = int(os.getenv("SEED_ITEMS", "100"))


@lru_cache

def get_settings() -> Settings:
    return Settings()
