from collections import Counter
from typing import List, Dict, Any
from age.core.scoring import freshness_score, novelty_penalty, exploration_bonus


def rank_candidates(user_state, candidates: List[Dict[str, Any]], top_k: int = 10) -> List[Dict[str, Any]]:
    recent_topics = Counter(c["topic"] for c in candidates[:15])
    ranked = []
    for pos, c in enumerate(candidates):
        topic_count = recent_topics.get(c["topic"], 0)
        score = (
            0.58 * c["similarity"]
            + 0.20 * freshness_score(c.get("freshness", 0.5))
            + 0.12 * exploration_bonus(user_state.exploration_rate, pos)
            + 0.10 * (1.0 - novelty_penalty(topic_count))
        )
        reason = {
            "similarity": round(c["similarity"], 4),
            "freshness": round(freshness_score(c.get("freshness", 0.5)), 4),
            "explore": round(exploration_bonus(user_state.exploration_rate, pos), 4),
            "topic_repeat": int(topic_count),
        }
        ranked.append({
            "item_id": c["item_id"],
            "title": c["title"],
            "topic": c["topic"],
            "score": float(score),
            "reason": reason,
        })
    ranked.sort(key=lambda x: x["score"], reverse=True)
    return _rerank_diversity(ranked[:top_k])


def _rerank_diversity(items: List[Dict[str, Any]], max_same_topic: int = 2) -> List[Dict[str, Any]]:
    out = []
    seen = Counter()
    for item in items:
        if seen[item["topic"]] >= max_same_topic:
            item = dict(item)
            item["score"] *= 0.95
            item["reason"] = dict(item["reason"])
            item["reason"]["diversity_penalty"] = 0.05
        else:
            item = dict(item)
            item["reason"] = dict(item["reason"])
            item["reason"]["diversity_penalty"] = 0.0
        seen[item["topic"]] += 1
        out.append(item)
    out.sort(key=lambda x: x["score"], reverse=True)
    return out
