from sqlalchemy import Column, String, Float, DateTime, Integer, JSON, Text, Index
from sqlalchemy.sql import func
from age.db.session import Base


class UserState(Base):
    __tablename__ = "user_state"
    user_id = Column(String, primary_key=True)
    long_term_vector = Column(JSON, nullable=False, default=list)
    session_vector = Column(JSON, nullable=False, default=list)
    context_vector = Column(JSON, nullable=False, default=list)
    last_event_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    entropy = Column(Float, nullable=False, default=1.0)
    exploration_rate = Column(Float, nullable=False, default=0.15)


class Item(Base):
    __tablename__ = "items"
    item_id = Column(String, primary_key=True)
    title = Column(String, nullable=False)
    body = Column(Text, nullable=False, default="")
    topic = Column(String, nullable=False, default="general")
    embedding = Column(JSON, nullable=False, default=list)
    freshness = Column(Float, nullable=False, default=0.5)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, index=True, nullable=False)
    item_id = Column(String, index=True, nullable=True)
    event_type = Column(String, nullable=False)
    value = Column(Float, nullable=False, default=1.0)
    context = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)


class RecommendationLog(Base):
    __tablename__ = "recommendation_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, index=True, nullable=False)
    item_id = Column(String, index=True, nullable=False)
    score = Column(Float, nullable=False)
    reason = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)


Index("ix_events_user_created", Event.user_id, Event.created_at)
