from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from redis import Redis
from age.config.settings import get_settings
from age.db.session import Base, engine, get_db
from age.db.models import UserState, Item
from age.core.schemas import EventIn, RecommendationResponse
from age.core.state import get_user_state, save_user_state
from age.ingestion.events import ingest_event
from age.retrieval.vector_store import retrieve_candidates
from age.ranking.ranker import rank_candidates
from age.scripts.seed_catalog import seed

settings = get_settings()
app = FastAPI(title=settings.app_name)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

redis_client = None
try:
    redis_client = Redis.from_url(settings.redis_url, decode_responses=True)
except Exception:
    redis_client = None


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    seed()


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name}


@app.post("/event")
def post_event(event: EventIn, db: Session = Depends(get_db)):
    row = ingest_event(db, event, redis_client=redis_client)
    return {"status": "accepted", "event_id": row.id}


@app.get("/recommendations", response_model=RecommendationResponse)
def recommendations(user_id: str, k: int = 10, db: Session = Depends(get_db)):
    state = get_user_state(db, user_id)
    candidates = retrieve_candidates(db, state.vector, top_k=max(50, k * 5))
    ranked = rank_candidates(state, candidates, top_k=k)
    for item in ranked:
        pass
    return RecommendationResponse(user_id=user_id, items=ranked)


@app.post("/state/reset")
def reset_state(user_id: str, db: Session = Depends(get_db)):
    row = db.get(UserState, user_id)
    if row:
        db.delete(row)
        db.commit()
    return {"status": "reset"}
