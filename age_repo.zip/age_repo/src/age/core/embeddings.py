import hashlib
import math
from typing import List


def _hash_to_float(seed: str, index: int) -> float:
    digest = hashlib.sha256(f"{seed}:{index}".encode()).hexdigest()
    return (int(digest[:8], 16) / 0xFFFFFFFF) * 2 - 1


def text_to_embedding(text: str, dim: int = 64) -> List[float]:
    tokens = (text or "").lower().split()
    if not tokens:
        tokens = ["empty"]
    vec = [0.0] * dim
    for t in tokens:
        for i in range(dim):
            vec[i] += _hash_to_float(t, i)
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def mean_vector(vectors: List[List[float]], dim: int = 64) -> List[float]:
    if not vectors:
        return [0.0] * dim
    out = [0.0] * dim
    for vec in vectors:
        for i, v in enumerate(vec[:dim]):
            out[i] += v
    n = float(len(vectors))
    return [v / n for v in out]
