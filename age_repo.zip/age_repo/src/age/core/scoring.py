import math
from typing import List


def cosine(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    n = min(len(a), len(b))
    dot = sum(a[i] * b[i] for i in range(n))
    na = math.sqrt(sum(a[i] * a[i] for i in range(n))) or 1.0
    nb = math.sqrt(sum(b[i] * b[i] for i in range(n))) or 1.0
    return dot / (na * nb)


def freshness_score(value: float) -> float:
    return max(0.0, min(1.0, value))


def novelty_penalty(recent_topic_count: int) -> float:
    return min(1.0, recent_topic_count / 3.0)


def exploration_bonus(exploration_rate: float, rank_position: int) -> float:
    return exploration_rate / (rank_position + 1)
