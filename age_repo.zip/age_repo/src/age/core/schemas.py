from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional


class EventIn(BaseModel):
    user_id: str
    item_id: Optional[str] = None
    event_type: str
    value: float = 1.0
    context: Dict[str, Any] = Field(default_factory=dict)


class ItemOut(BaseModel):
    item_id: str
    title: str
    topic: str
    score: float
    reason: Dict[str, Any] = Field(default_factory=dict)


class RecommendationResponse(BaseModel):
    user_id: str
    items: List[ItemOut]
