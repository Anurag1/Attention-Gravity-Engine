from dataclasses import dataclass, field
from typing import List
from sqlalchemy.orm import Session
from age.db.models import UserState as UserStateModel
from age.core.embeddings import mean_vector
from age.feedback.processor import reward_from_event


@dataclass
class UserState:
    user_id: str
    long_term_vector: List[float] = field(default_factory=list)
    session_vector: List[float] = field(default_factory=list)
    context_vector: List[float] = field(default_factory=list)
    entropy: float = 1.0
    exploration_rate: float = 0.15

    @property
    def vector(self) -> List[float]:
        if not self.long_term_vector:
            return self.session_vector or self.context_vector or []
        dim = len(self.long_term_vector)
        out = [0.0] * dim
        for i in range(dim):
            out[i] = (
                0.6 * self.long_term_vector[i]
                + 0.3 * (self.session_vector[i] if i < len(self.session_vector) else 0.0)
                + 0.1 * (self.context_vector[i] if i < len(self.context_vector) else 0.0)
            )
        return out


def _empty_state(user_id: str, dim: int = 64) -> UserState:
    return UserState(
        user_id=user_id,
        long_term_vector=[0.0] * dim,
        session_vector=[0.0] * dim,
        context_vector=[0.0] * dim,
        entropy=1.0,
        exploration_rate=0.15,
    )


def get_user_state(db: Session, user_id: str, dim: int = 64) -> UserState:
    row = db.get(UserStateModel, user_id)
    if not row:
        return _empty_state(user_id, dim)
    return UserState(
        user_id=row.user_id,
        long_term_vector=row.long_term_vector or [0.0] * dim,
        session_vector=row.session_vector or [0.0] * dim,
        context_vector=row.context_vector or [0.0] * dim,
        entropy=row.entropy,
        exploration_rate=row.exploration_rate,
    )


def save_user_state(db: Session, state: UserState) -> None:
    row = db.get(UserStateModel, state.user_id)
    if not row:
        row = UserStateModel(user_id=state.user_id)
    row.long_term_vector = state.long_term_vector
    row.session_vector = state.session_vector
    row.context_vector = state.context_vector
    row.entropy = state.entropy
    row.exploration_rate = state.exploration_rate
    db.add(row)
    db.commit()


def update_state_from_reaction(state: UserState, item_vector: List[float], event_type: str, value: float) -> UserState:
    reward = reward_from_event(event_type, value)
    if not state.long_term_vector:
        state.long_term_vector = item_vector[:]
    if not state.session_vector:
        state.session_vector = item_vector[:]
    alpha = 0.92 if reward >= 0 else 0.97
    beta = 1.0 - alpha
    state.long_term_vector = [alpha * s + beta * reward * i for s, i in zip(state.long_term_vector, item_vector)]
    state.session_vector = [0.85 * s + 0.15 * reward * i for s, i in zip(state.session_vector, item_vector)]
    state.entropy = max(0.05, min(2.0, state.entropy * (0.99 if reward > 0 else 1.01)))
    state.exploration_rate = max(0.05, min(0.35, 0.12 + 0.1 * state.entropy))
    return state
