from typing import List, Dict, Any
from sqlalchemy.orm import Session
from age.db.models import Item
from age.core.scoring import cosine


def retrieve_candidates(db: Session, user_vector: List[float], top_k: int = 100) -> List[Dict[str, Any]]:
    items = db.query(Item).all()
    scored = []
    for item in items:
        sim = cosine(user_vector, item.embedding or [])
        scored.append({
            "item_id": item.item_id,
            "title": item.title,
            "topic": item.topic,
            "embedding": item.embedding or [],
            "similarity": sim,
            "freshness": item.freshness,
            "metadata": {"body": item.body},
        })
    scored.sort(key=lambda x: x["similarity"], reverse=True)
    return scored[:top_k]
