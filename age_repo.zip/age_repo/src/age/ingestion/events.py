import json
from typing import Optional
from sqlalchemy.orm import Session
from redis import Redis
from age.core.schemas import EventIn
from age.db.models import Event

STREAM_NAME = "age.events"


def ingest_event(db: Session, event: EventIn, redis_client: Optional[Redis] = None) -> Event:
    row = Event(
        user_id=event.user_id,
        item_id=event.item_id,
        event_type=event.event_type,
        value=event.value,
        context=event.context,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    if redis_client is not None:
        redis_client.xadd(STREAM_NAME, {"event": json.dumps(event.model_dump())})
    return row
