def reward_from_event(event_type: str, value: float = 1.0) -> float:
    mapping = {
        "impression": 0.02,
        "click": 1.0,
        "dwell": 0.75,
        "save": 1.2,
        "share": 1.3,
        "skip": -0.7,
        "hide": -1.2,
        "bounce": -0.8,
    }
    return mapping.get(event_type, 0.0) * value
