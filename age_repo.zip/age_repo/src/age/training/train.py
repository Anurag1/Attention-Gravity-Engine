from sqlalchemy.orm import Session
from age.db.session import SessionLocal, engine, Base
from age.training.retrainer import recompute_item_embeddings


def main():
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    updated = recompute_item_embeddings(db)
    print(f"updated {updated} item embeddings")
    db.close()


if __name__ == "__main__":
    main()
