from sqlalchemy.orm import Session
from age.db.models import Item
from age.core.embeddings import text_to_embedding


def recompute_item_embeddings(db: Session, dim: int = 64) -> int:
    count = 0
    for item in db.query(Item).all():
        item.embedding = text_to_embedding(f"{item.title} {item.body} {item.topic}", dim=dim)
        count += 1
    db.commit()
    return count
