If you replace Redis Streams with Kafka, use these topics:

- age.events
- age.recommendations
- age.state.updates
- age.training.jobs
