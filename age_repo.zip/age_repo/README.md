# Attention Gravity Engine (AGE)

A small but real starter system for a self-evolving recommendation loop.

## What it does

- ingests behavior events
- stores user state in Postgres
- computes item embeddings deterministically
- retrieves candidates by similarity
- ranks with freshness, diversity, and exploration
- updates user state in real time through a worker

## Stack

- FastAPI
- PostgreSQL
- Redis Streams
- SQLAlchemy
- Docker Compose

## Run locally

```bash
cp .env.example .env
docker compose up --build
```

Open:

- `GET /health`
- `POST /seed`
- `GET /recommendations?user_id=u1`
- `POST /event`

## Endpoints

### `POST /event`

```json
{
  "user_id": "u1",
  "item_id": "item_12",
  "event_type": "click",
  "value": 1,
  "context": {"source": "home_feed"}
}
```

### `GET /recommendations?user_id=u1&k=10`

Returns ranked items with scores and explanations.

## The loop

1. user acts
2. event is stored and streamed
3. worker updates state
4. retriever fetches candidates
5. ranker selects the next items
6. feedback changes the state

## Next layer already included

- state decay
- exploration bonus
- novelty penalty
- topic diversity control
- online event consumer
- seeded catalog generator

## Deploy

The repo is ready for Docker Compose now. For Kubernetes, reuse the same image and add manifests under `infra/deployment/`.
